﻿async function login() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const errorMsg = document.getElementById('errorMsg');
    errorMsg.textContent = "";

    if (!username || !password) {
        errorMsg.textContent = "Debe completar todos los campos.";
        return;
    }

    try {
        const response = await fetch("https://localhost:7173/api/Usuario/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ userName: username, password: password })
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem("Rol", data.rol);
            localStorage.setItem("UserName", data.userName);

            // Redirección según rol
            switch (data.rol.toLowerCase()) {
                case "administrador":
                    window.location.href = "admin.html";
                    break;
                case "operador":
                    window.location.href = "operador.html";
                    break;
                case "cliente":
                    window.location.href = "cliente.html";
                    break;
                default:
                    errorMsg.textContent = "Rol no reconocido.";
            }
        } else {
            errorMsg.textContent = "Usuario o contraseña incorrectos.";
        }
    } catch (error) {
        console.error("Error de conexión:", error);
        errorMsg.textContent = "Error de conexión con el servidor.";
    }
}
