﻿document.addEventListener("DOMContentLoaded", async () => {
    const cedula = localStorage.getItem("CedulaCliente");
    const nombre = localStorage.getItem("NombreCliente");
    if (!cedula) {
        alert("No se encontró sesión activa. Inicia sesión nuevamente.");
        window.location.href = "../login.html";
        return;
    }

    document.getElementById("clienteNombre").textContent = nombre;

    try {
        const response = await fetch(`https://localhost:7173/api/Prestamo/porCliente/${cedula}`);
        if (!response.ok) throw new Error("No se pudieron obtener los préstamos.");

        const prestamos = await response.json();
        const tbody = document.getElementById("tablaPrestamosCliente");

        for (const p of prestamos) {
            // Obtener observaciones si existen
            let observacionesTexto = "-";
            if (p.observaciones && p.observaciones.length > 0) {
                observacionesTexto = p.observaciones.map(o => `• ${o.descripcion}`).join("<br>");
            }

            const fila = `
            <tr>
                <td>${p.id}</td>
                <td>${p.articulo.nombre} (${p.articulo.codigo})</td>
                <td>${p.estadoArticuloAntes}</td>
                <td>${p.estadoArticuloDespues || "-"}</td>
                <td>${new Date(p.fechaPrestamo).toLocaleDateString()}</td>
                <td>${p.fechaDevolucion ? new Date(p.fechaDevolucion).toLocaleDateString() : "-"}</td>
                <td>${p.estado}</td>
                <td>${observacionesTexto}</td>
            </tr>
        `;
            tbody.innerHTML += fila;
        }
    } catch (error) {
        console.error("Error al cargar datos:", error);
        alert("Hubo un problema al cargar tus préstamos.");
    }
});

function cerrarSesion() {
    localStorage.clear();
    window.location.href = "../login.html";
}