﻿const URL_API = "https://localhost:7173/api/Articulo";
let editandoId = null;

document.getElementById("btnNuevo").addEventListener("click", () => {
    document.getElementById("formularioArticulo").classList.remove("d-none");
    limpiarFormulario();
    document.getElementById("tituloFormulario").innerText = "Nuevo Artículo";
    editandoId = null;
});

document.getElementById("btnCancelar").addEventListener("click", () => {
    document.getElementById("formularioArticulo").classList.add("d-none");
    limpiarFormulario();
});

document.getElementById("btnGuardar").addEventListener("click", async () => {
    const articulo = {
        nombre: document.getElementById("nombre").value,
        codigo: document.getElementById("codigo").value,
        categoria: document.getElementById("categoria").value,
        estado: document.getElementById("estado").value,
        ubicacion: document.getElementById("ubicacion").value
    };

    if (!articulo.nombre || !articulo.codigo) {
        alert("Nombre y Código son obligatorios");
        return;
    }

    try {
        if (editandoId) {
            await fetch(`${URL_API}/${editandoId}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id: editandoId, ...articulo })
            });
        } else {
            await fetch(URL_API, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(articulo)
            });
        }

        limpiarFormulario();
        document.getElementById("formularioArticulo").classList.add("d-none");
        await cargarArticulos();
    } catch (error) {
        console.error("Error al guardar artículo:", error);
    }
});

async function cargarArticulos() {
    const cuerpo = document.getElementById("tablaArticulos");
    cuerpo.innerHTML = "";
    const filtro = document.getElementById("buscarArticulo").value.toLowerCase();

    try {
        const res = await fetch(URL_API);
        const articulos = await res.json();

        articulos
            .filter(a => a.nombre.toLowerCase().includes(filtro))
            .forEach(art => {
                const fila = document.createElement("tr");
                fila.innerHTML = `
          <td>${art.id}</td>
          <td>${art.nombre}</td>
          <td>${art.codigo}</td>
          <td>${art.categoria}</td>
          <td>${art.estado}</td>
          <td>${art.ubicacion}</td>
          <td>
            <button class="btn btn-warning btn-sm me-2" onclick="editarArticulo(${art.id})">Editar</button>
            <button class="btn btn-danger btn-sm" onclick="eliminarArticulo(${art.id})">Eliminar</button>
          </td>
        `;
                cuerpo.appendChild(fila);
            });
    } catch (error) {
        console.error("Error al cargar artículos:", error);
    }
}

async function editarArticulo(id) {
    try {
        const res = await fetch(`${URL_API}/${id}`);
        const art = await res.json();

        editandoId = art.id;
        document.getElementById("nombre").value = art.nombre;
        document.getElementById("codigo").value = art.codigo;
        document.getElementById("categoria").value = art.categoria;
        document.getElementById("estado").value = art.estado;
        document.getElementById("ubicacion").value = art.ubicacion;
        document.getElementById("formularioArticulo").classList.remove("d-none");
        document.getElementById("tituloFormulario").innerText = "Editar Artículo";
    } catch (error) {
        console.error("Error al cargar artículo:", error);
    }
}

async function eliminarArticulo(id) {
    if (!confirm("¿Estás seguro de eliminar este artículo?")) return;

    try {
        const res = await fetch(`${URL_API}/${id}`, {
            method: "DELETE"
        });

        if (!res.ok) throw new Error("Error al eliminar el artículo.");

        alert("Artículo eliminado correctamente ✅");
        cargarArticulos(); // recarga la tabla
    } catch (error) {
        console.error("Error al eliminar:", error);
        alert("No se pudo eliminar el artículo.");
    }
}


function limpiarFormulario() {
    document.getElementById("nombre").value = "";
    document.getElementById("codigo").value = "";
    document.getElementById("categoria").value = "";
    document.getElementById("estado").value = "";
    document.getElementById("ubicacion").value = "";
    editandoId = null;
}

document.getElementById("buscarArticulo").addEventListener("input", cargarArticulos);

function cerrarSesion() {
    alert("Sesión cerrada (simulada)");
}

cargarArticulos();
function exportarArticulosPDF() {
    fetch("https://localhost:7173/api/Articulo")
        .then(res => res.json())
        .then(data => {
            const doc = new jspdf.jsPDF();
            doc.text("Listado de Artículos", 10, 10);
            const columnas = ["ID", "Nombre", "Código", "Categoría", "Estado", "Ubicación"];
            const filas = data.map(a => [a.id, a.nombre, a.codigo, a.categoria, a.estado, a.ubicacion]);
            doc.autoTable({ head: [columnas], body: filas, startY: 20 });
            doc.save("articulos.pdf");
        });
}

function exportarArticulosExcel() {
    fetch("https://localhost:7173/api/Articulo")
        .then(res => res.json())
        .then(data => {
            const wb = XLSX.utils.book_new();
            const ws = XLSX.utils.json_to_sheet(data.map(a => ({
                ID: a.id,
                Nombre: a.nombre,
                Código: a.codigo,
                Categoría: a.categoria,
                Estado: a.estado,
                Ubicación: a.ubicacion
            })));
            XLSX.utils.book_append_sheet(wb, ws, "Artículos");
            XLSX.writeFile(wb, "articulos.xlsx");
        });
}


// ================== EMPLEADOS =====================
document.addEventListener("DOMContentLoaded", () => {
    cargarEmpleados();

    document.getElementById("btnNuevoEmpleado").onclick = () => {
        mostrarFormularioEmpleado();
    };

    document.getElementById("btnCancelarEmpleado").onclick = ocultarFormularioEmpleado;
    document.getElementById("btnGuardarEmpleado").onclick = guardarEmpleado;

    document.getElementById("btnAgregarUsuario").onclick = () => {
        document.getElementById("formularioUsuario").classList.remove("d-none");
    };
    document.getElementById("btnCancelarUsuario").onclick = () => {
        document.getElementById("formularioUsuario").classList.add("d-none");
        ["usuarioCedula", "userName", "password", "rol"].forEach(id => {
            document.getElementById(id).value = "";
        });
    };
    document.getElementById("btnGuardarUsuario").onclick = guardarUsuario;
});

async function cargarEmpleados() {
    try {
        const response = await fetch('https://localhost:7173/api/Empleado');
        const empleados = await response.json();

        const usuariosResponse = await fetch('https://localhost:7173/api/Usuario');
        const usuarios = await usuariosResponse.json();

        const tabla = document.getElementById("tablaEmpleados");
        tabla.innerHTML = "";

        empleados.forEach(e => {
            const usuario = usuarios.find(u => u.empleado?.cedula === e.cedula);
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${e.cedula}</td>
                <td>${e.nombre}</td>
                <td>${e.apellido}</td>
                <td>${e.telefono}</td>
                <td>${e.correo}</td>
                <td>${usuario ? usuario.userName : '-'}</td>
                <td>${usuario ? usuario.rol : '-'}</td>
                <td>
                    <button class="btn btn-warning btn-sm me-2" onclick="editarEmpleado('${e.cedula}')">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="eliminarEmpleado('${e.cedula}')">Eliminar</button>
                </td>
            `;
            tabla.appendChild(tr);
        });
    } catch (error) {
        console.error("Error al cargar empleados y usuarios:", error);
    }
}

function mostrarFormularioEmpleado() {
    document.getElementById("formularioEmpleado").classList.remove("d-none");
    document.getElementById("tituloEmpleado").innerText = "Nuevo Empleado";
    limpiarCamposEmpleado();
}

function ocultarFormularioEmpleado() {
    document.getElementById("formularioEmpleado").classList.add("d-none");
}

function limpiarCamposEmpleado() {
    ["cedula", "nombreEmpleado", "apellidoEmpleado", "telefonoEmpleado", "correoEmpleado"].forEach(id => {
        document.getElementById(id).value = "";
    });
}

async function guardarEmpleado() {
    const empleado = {
        cedula: document.getElementById("cedula").value,
        nombre: document.getElementById("nombreEmpleado").value,
        apellido: document.getElementById("apellidoEmpleado").value,
        telefono: document.getElementById("telefonoEmpleado").value,
        correo: document.getElementById("correoEmpleado").value,
    };

    await fetch("https://localhost:7173/api/Empleado", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(empleado)
    });

    ocultarFormularioEmpleado();
    cargarEmpleados();
}

async function editarEmpleado(cedula) {
    try {
        const response = await fetch(`https://localhost:7173/api/Empleado/${cedula}`);
        const e = await response.json();
        document.getElementById("cedula").value = e.cedula;
        document.getElementById("nombreEmpleado").value = e.nombre;
        document.getElementById("apellidoEmpleado").value = e.apellido;
        document.getElementById("telefonoEmpleado").value = e.telefono;
        document.getElementById("correoEmpleado").value = e.correo;
        document.getElementById("formularioEmpleado").classList.remove("d-none");
        document.getElementById("tituloEmpleado").innerText = "Editar Empleado";
    } catch (error) {
        alert("Error al cargar datos del empleado.");
        console.error(error);
    }
}

async function eliminarEmpleado(cedula) {
    if (!confirm("¿Deseas eliminar este empleado?")) return;
    await fetch(`https://localhost:7173/api/Empleado/${cedula}`, { method: "DELETE" });
    cargarEmpleados();
}

async function guardarUsuario() {
    const cedula = document.getElementById("usuarioCedula").value.trim();
    const userName = document.getElementById("userName").value.trim();
    const password = document.getElementById("password").value.trim();
    const rol = document.getElementById("rol").value;

    if (!cedula || !userName || !password || !rol) {
        alert("Por favor, complete todos los campos del usuario.");
        return;
    }

    const usuario = {
        empleadoCedula: cedula,
        userName,
        password,
        rol
    };

    try {
        const response = await fetch("https://localhost:7173/api/Usuario", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(usuario)
        });

        if (response.ok) {
            alert("Usuario registrado correctamente.");
            document.getElementById("formularioUsuario").classList.add("d-none");
            ["usuarioCedula", "userName", "password", "rol"].forEach(id => document.getElementById(id).value = "");
            cargarEmpleados();
        } else {
            const error = await response.json();
            alert("Error al registrar el usuario: " + (error.mensaje || "Error desconocido"));
        }
    } catch (error) {
        alert("Error al conectar con el servidor.");
        console.error(error);
    }
}
// ================== CLIENTES =====================
// ================== CLIENTES =====================
document.addEventListener("DOMContentLoaded", () => {
    cargarClientes();

    document.getElementById("btnNuevoCliente").onclick = mostrarFormularioCliente;
    document.getElementById("btnCancelarCliente").onclick = ocultarFormularioCliente;
    document.getElementById("btnGuardarCliente").onclick = guardarCliente;

    document.getElementById("buscarCliente").addEventListener("input", cargarClientes);
});

async function cargarClientes() {
    try {
        const filtro = document.getElementById("buscarCliente").value.toLowerCase();
        const response = await fetch('https://localhost:7173/api/Cliente');
        const clientes = await response.json();

        const tabla = document.getElementById("tablaClientes");
        tabla.innerHTML = "";

        clientes
            .filter(c => c.nombre.toLowerCase().includes(filtro) || c.cedula.includes(filtro))
            .forEach(c => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${c.cedula}</td>
                    <td>${c.nombre}</td>
                    <td>${c.apellido}</td>
                    <td>${c.celular || '-'}</td>
                    <td>
                        <button class="btn btn-warning btn-sm me-2" onclick="editarCliente('${c.cedula}')">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarCliente('${c.cedula}')">Eliminar</button>
                    </td>
                `;
                tabla.appendChild(tr);
            });
    } catch (error) {
        console.error("Error al cargar clientes:", error);
    }
}

function mostrarFormularioCliente() {
    document.getElementById("formularioCliente").classList.remove("d-none");
    document.getElementById("tituloCliente").innerText = "Nuevo Cliente";
    limpiarCamposCliente();
}

function ocultarFormularioCliente() {
    document.getElementById("formularioCliente").classList.add("d-none");
    limpiarCamposCliente();
}

function limpiarCamposCliente() {
    document.getElementById("cedulaCliente").value = "";
    document.getElementById("nombreCliente").value = "";
    document.getElementById("apellidoCliente").value = "";
    document.getElementById("celularCliente").value = "";
}

async function guardarCliente() {
    const cliente = {
        cedula: document.getElementById("cedulaCliente").value,
        nombre: document.getElementById("nombreCliente").value,
        apellido: document.getElementById("apellidoCliente").value,
        celular: document.getElementById("celularCliente").value
    };

    if (!cliente.cedula || !cliente.nombre || !cliente.apellido) {
        alert("Cédula, nombre y apellido son obligatorios.");
        return;
    }

    try {
        const response = await fetch("https://localhost:7173/api/Cliente", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(cliente)
        });

        if (response.ok) {
            ocultarFormularioCliente();
            cargarClientes();
        } else {
            const error = await response.json();
            alert("Error al guardar: " + (error.mensaje || "Desconocido"));
        }
    } catch (error) {
        alert("Error al guardar el cliente.");
        console.error(error);
    }
}

async function editarCliente(cedula) {
    try {
        const res = await fetch(`https://localhost:7173/api/Cliente/${cedula}`);
        const c = await res.json();

        document.getElementById("cedulaCliente").value = c.cedula;
        document.getElementById("nombreCliente").value = c.nombre;
        document.getElementById("apellidoCliente").value = c.apellido;
        document.getElementById("celularCliente").value = c.celular || "";

        document.getElementById("formularioCliente").classList.remove("d-none");
        document.getElementById("tituloCliente").innerText = "Editar Cliente";
    } catch (error) {
        alert("Error al cargar el cliente.");
        console.error(error);
    }
}

async function eliminarCliente(cedula) {
    if (!confirm("¿Deseas eliminar este cliente?")) return;
    try {
        await fetch(`https://localhost:7173/api/Cliente/${cedula}`, { method: "DELETE" });
        cargarClientes();
    } catch (error) {
        alert("Error al eliminar el cliente.");
        console.error(error);
    }
}
// admin.js – Sección de Préstamos
document.addEventListener("DOMContentLoaded", () => {
    cargarPrestamos();
    document.getElementById("btnNuevoPrestamo").addEventListener("click", () => {
        alert("Funcionalidad de nuevo préstamo aún no implementada.");
    });
});

async function cargarPrestamos() {
    try {
        const response = await fetch("https://localhost:7173/api/Prestamo");
        const prestamos = await response.json();
        const tabla = document.getElementById("tablaPrestamos");
        tabla.innerHTML = "";

        prestamos.forEach(p => {
            const observaciones = (p.observaciones && p.observaciones.length > 0)
                ? p.observaciones.join("<br>")
                : "-";

            const tr = document.createElement("tr");
            tr.innerHTML = `
        <td>${p.id}</td>
        <td>${p.articuloNombre}</td>
        <td>${p.clienteNombre}</td>
        <td>${p.empleadoNombre}</td>
        <td>${p.fechaPrestamo.split("T")[0]}</td>
        <td>${p.estado}</td>
        <td>${observaciones}</td>
        <td>
          <button class="btn btn-warning btn-sm me-2">Editar</button>
          <button class="btn btn-danger btn-sm">Eliminar</button>
        </td>
      `;
            tabla.appendChild(tr);
        });
    } catch (error) {
        console.error("Error al cargar préstamos:", error);
    }
}
document.getElementById("btnExportarPrestamosPDF").addEventListener("click", exportarPrestamosPDF);
document.getElementById("btnExportarPrestamosExcel").addEventListener("click", exportarPrestamosExcel);

async function exportarPrestamosPDF() {
    const res = await fetch("https://localhost:7173/api/Prestamo");
    const prestamos = await res.json();

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFontSize(12);
    doc.text("Reporte de Préstamos", 14, 10);

    const rows = prestamos.map(p => [
        p.id,
        p.articuloNombre,
        p.clienteNombre,
        p.empleadoNombre,
        p.fechaPrestamo.split("T")[0],
        p.estado,
        (p.observaciones || []).join(", ")
    ]);

    doc.autoTable({
        head: [["ID", "Artículo", "Cliente", "Empleado", "Fecha", "Estado", "Observaciones"]],
        body: rows,
        startY: 20
    });

    doc.save("prestamos.pdf");
}

async function exportarPrestamosExcel() {
    const res = await fetch("https://localhost:7173/api/Prestamo");
    const prestamos = await res.json();

    const wsData = [
        ["ID", "Artículo", "Cliente", "Empleado", "Fecha", "Estado", "Observaciones"],
        ...prestamos.map(p => [
            p.id,
            p.articuloNombre,
            p.clienteNombre,
            p.empleadoNombre,
            p.fechaPrestamo.split("T")[0],
            p.estado,
            (p.observaciones || []).join(", ")
        ])
    ];

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    XLSX.utils.book_append_sheet(wb, ws, "Préstamos");
    XLSX.writeFile(wb, "prestamos.xlsx");
}

