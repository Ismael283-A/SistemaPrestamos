﻿document.addEventListener("DOMContentLoaded", () => {
    cargarPrestamos();
    document.getElementById("btnNuevoPrestamo").addEventListener("click", () => {
        alert("Funcionalidad de nuevo préstamo aún no implementada.");
    });
});

async function cargarPrestamos() {
    try {
        const response = await fetch("https://localhost:7173/api/Prestamo");
        const prestamos = await response.json();
        const tabla = document.getElementById("tablaPrestamos");
        tabla.innerHTML = "";

        prestamos.forEach(p => {
            const observaciones = (p.observaciones && p.observaciones.length > 0)
                ? p.observaciones.join("<br>")
                : "-";

            const tr = document.createElement("tr");
            tr.innerHTML = `
        <td>${p.id}</td>
        <td>${p.articuloNombre}</td>
        <td>${p.clienteNombre}</td>
        <td>${p.empleadoNombre}</td>
        <td>${p.fechaPrestamo.split("T")[0]}</td>
        <td>${p.estado}</td>
        <td>${observaciones}</td>
        <td>
          <button class="btn btn-warning btn-sm me-2">Editar</button>
          <button class="btn btn-danger btn-sm">Eliminar</button>
        </td>
      `;
            tabla.appendChild(tr);
        });
    } catch (error) {
        console.error("Error al cargar préstamos:", error);
    }
}