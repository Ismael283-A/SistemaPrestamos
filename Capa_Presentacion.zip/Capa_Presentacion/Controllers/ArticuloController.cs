﻿using Capa_Business.Services.Interfaces;
using Capa_Entities.Models;
using Microsoft.AspNetCore.Mvc;

namespace Capa_Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ArticuloController : ControllerBase
    {
        private readonly IArticuloService _service;

        public ArticuloController(IArticuloService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var lista = await _service.ObtenerTodosAsync();
            return Ok(lista);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var item = await _service.ObtenerPorIdAsync(id);
            if (item == null) return NotFound();
            return Ok(item);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Articulo articulo)
        {
            await _service.CrearAsync(articulo);
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Articulo articulo)
        {
            if (id != articulo.Id) return BadRequest();
            await _service.ActualizarAsync(articulo);
            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
   
            await _service.EliminarAsync(id);
            return Ok("Artículo eliminado correctamente.");
        }

    }
}
