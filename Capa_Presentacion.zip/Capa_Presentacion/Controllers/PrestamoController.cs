﻿using Capa_Business.Services.Interfaces;
using Capa_Entities.Models;
using Capa_Entities.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace Capa_Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PrestamoController : ControllerBase
    {
        private readonly IPrestamoService _prestamoService;
        private readonly IArticuloService _articuloService;
        private readonly IEmpleadoService _empleadoService;
        private readonly IClienteService _clienteService;

        public PrestamoController(
            IPrestamoService prestamoService,
            IArticuloService articuloService,
            IEmpleadoService empleadoService,
            IClienteService clienteService)
        {
            _prestamoService = prestamoService;
            _articuloService = articuloService;
            _empleadoService = empleadoService;
            _clienteService = clienteService;
        }

        // GET: api/Prestamo
        //[HttpGet]
        //public async Task<IActionResult> GetAll()
        //{
        //    var prestamos = await _prestamoService.ObtenerTodosAsync();

        //    var result = prestamos.Select(p => new PrestamoGetDTO
        //    {
        //        Id = p.Id,
        //        FechaPrestamo = p.FechaPrestamo,
        //        FechaDevolucion = p.FechaDevolucion,
        //        EstadoArticuloAntes = p.EstadoArticuloAntes,
        //        EstadoArticuloDespues = p.EstadoArticuloDespues,
        //        Estado = p.Estado,
        //        ArticuloNombre = p.Articulo?.Nombre ?? "Desconocido",
        //        EmpleadoNombre = p.Empleado?.Nombre ?? "Desconocido",
        //        ClienteNombre = p.Cliente?.Nombre ?? "Desconocido",
        //        Observaciones = p.Observaciones?.Select(o => o.Descripcion).ToList()
        //    }).ToList();

        //    return Ok(result);
        //}

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var prestamos = await _prestamoService.ObtenerTodosAsync();

            var result = prestamos.Select(p => new PrestamoGetDTO
            {
                Id = p.Id,
                FechaPrestamo = p.FechaPrestamo,
                FechaDevolucion = p.FechaDevolucion,
                EstadoArticuloAntes = p.EstadoArticuloAntes,
                EstadoArticuloDespues = p.EstadoArticuloDespues,
                Estado = p.Estado,
                ArticuloNombre = p.Articulo?.Nombre ?? "-",
                EmpleadoNombre = p.Empleado?.Nombre ?? "-",
                ClienteNombre = p.Cliente?.Nombre ?? "-",
                Observaciones = p.Observaciones?.Select(o => o.Descripcion).ToList() ?? new List<string>()
            }).ToList();

            return Ok(result);
        }

        // GET: api/Prestamo/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var p = await _prestamoService.ObtenerPorIdAsync(id);
            if (p == null)
                return NotFound();

            var dto = new PrestamoGetDTO
            {
                Id = p.Id,
                FechaPrestamo = p.FechaPrestamo,
                FechaDevolucion = p.FechaDevolucion,
                EstadoArticuloAntes = p.EstadoArticuloAntes,
                EstadoArticuloDespues = p.EstadoArticuloDespues,
                Estado = p.Estado,
                ArticuloNombre = p.Articulo?.Nombre ?? "Desconocido",
                EmpleadoNombre = p.Empleado?.Nombre ?? "Desconocido",
                ClienteNombre = p.Cliente?.Nombre ?? "Desconocido",
                Observaciones = p.Observaciones?.Select(o => o.Descripcion).ToList()
            };

            return Ok(dto);
        }

        // POST: api/Prestamo
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] PrestamoDTO dto)
        {
            var prestamo = new Prestamo
            {
                FechaPrestamo = dto.FechaPrestamo,
                FechaDevolucion = dto.FechaDevolucion,
                EstadoArticuloAntes = dto.EstadoArticuloAntes,
                EstadoArticuloDespues = dto.EstadoArticuloDespues,
                Estado = dto.Estado,
                ArticuloId = dto.ArticuloId,
                EmpleadoCedula = dto.EmpleadoCedula,
                ClienteCedula = dto.ClienteCedula,
                Observaciones = dto.Observaciones?.Select(desc => new Observacion
                {
                    Descripcion = desc
                }).ToList()
            };

            await _prestamoService.CrearAsync(prestamo);
            return Ok(new { mensaje = "Préstamo creado correctamente." });
        }

        // PUT: api/Prestamo/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] PrestamoDTO dto)
        {
            var prestamoExistente = await _prestamoService.ObtenerPorIdAsync(id);
            if (prestamoExistente == null)
                return NotFound();

            prestamoExistente.FechaPrestamo = dto.FechaPrestamo;
            prestamoExistente.FechaDevolucion = dto.FechaDevolucion;
            prestamoExistente.EstadoArticuloAntes = dto.EstadoArticuloAntes;
            prestamoExistente.EstadoArticuloDespues = dto.EstadoArticuloDespues;
            prestamoExistente.Estado = dto.Estado;
            prestamoExistente.ArticuloId = dto.ArticuloId;
            prestamoExistente.EmpleadoCedula = dto.EmpleadoCedula;
            prestamoExistente.ClienteCedula = dto.ClienteCedula;
            prestamoExistente.Observaciones = dto.Observaciones?.Select(desc => new Observacion
            {
                Descripcion = desc
            }).ToList();

            await _prestamoService.ActualizarAsync(prestamoExistente);
            return Ok(new { mensaje = "Préstamo actualizado correctamente." });
        }

        // DELETE: api/Prestamo/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var existe = await _prestamoService.ObtenerPorIdAsync(id);
            if (existe == null)
                return NotFound();

            await _prestamoService.EliminarAsync(id);
            return Ok(new { mensaje = "Préstamo eliminado correctamente." });
        }
    }
}
