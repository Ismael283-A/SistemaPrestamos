﻿using Capa_Business.Services.Interfaces;
using Capa_Entities.DTOs;
using Capa_Entities.Models;
using Microsoft.AspNetCore.Mvc;

namespace Capa_Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioService _usuarioService;

        public UsuarioController(IUsuarioService usuarioService)
        {
            _usuarioService = usuarioService;
        }
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Usuario usuario)
        {
            try
            {
                await _usuarioService.RegistrarAsync(usuario);
                return Ok("Usuario creado correctamente.");
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensaje = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Usuario usuario)
        {
            try
            {
                await _usuarioService.RegistrarAsync(usuario);
                return Ok("Usuario creado correctamente.");
            }
            catch (Exception ex)
            {
                return BadRequest(new { mensaje = ex.Message });
            }
        }




        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UsuarioLoginDto dto)
        {
            var usuario = await _usuarioService.LoginAsync(dto.UserName, dto.Password);
            if (usuario == null)
                return Unauthorized("Credenciales inválidas.");
            return Ok(new { usuario.UserName, usuario.Rol });
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var usuarios = await _usuarioService.ObtenerTodosAsync();
            return Ok(usuarios);
        }
        


    }


}
