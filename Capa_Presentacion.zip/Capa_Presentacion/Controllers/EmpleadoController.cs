﻿using Microsoft.AspNetCore.Mvc;
using Capa_Business.Services.Interfaces;
using Capa_Entities.Models;

namespace Capa_Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmpleadoController : ControllerBase
    {
        private readonly IEmpleadoService _empleadoService;

        public EmpleadoController(IEmpleadoService empleadoService)
        {
            _empleadoService = empleadoService;
        }

        // GET: api/Empleado
        [HttpGet]
        public async Task<IActionResult> ObtenerTodos()
        {
            var empleados = await _empleadoService.ObtenerTodosAsync();
            // TEMPORAL: imprime lo que devuelve
            Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(empleados));
            return Ok(empleados);
        }

        // GET: api/Empleado/{cedula}
        [HttpGet("{cedula}")]
        public async Task<IActionResult> ObtenerPorCedula(string cedula)
        {
            var empleado = await _empleadoService.ObtenerPorCedulaAsync(cedula);
            if (empleado == null)
                return NotFound();
            return Ok(empleado);
        }

        // POST: api/Empleado
        [HttpPost]
        public async Task<IActionResult> Crear([FromBody] Empleado empleado)
        {
            await _empleadoService.CrearAsync(empleado);
            return Ok("Empleado creado correctamente.");
        }

        // PUT: api/Empleado/{cedula}
        [HttpPut("{cedula}")]
        public async Task<IActionResult> Actualizar(string cedula, [FromBody] Empleado empleado)
        {
            if (cedula != empleado.Cedula)
                return BadRequest("La cédula no coincide.");

            await _empleadoService.ActualizarAsync(empleado);
            return Ok("Empleado actualizado correctamente.");
        }

        // DELETE: api/Empleado/{cedula}
        [HttpDelete("{cedula}")]
        public async Task<IActionResult> Eliminar(string cedula)
        {
            await _empleadoService.EliminarAsync(cedula);
            return Ok("Empleado eliminado correctamente.");
        }
    }
}
