﻿using Capa_Business.Services.Interfaces;
using Capa_Entities.Models;
using Microsoft.AspNetCore.Mvc;

namespace Capa_Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ClienteController : ControllerBase
    {
        private readonly IClienteService _service;

        public ClienteController(IClienteService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll() => Ok(await _service.ObtenerTodosAsync());

        [HttpGet("{cedula}")]
        public async Task<IActionResult> GetById(string cedula)
        {
            var cli = await _service.ObtenerPorCedulaAsync(cedula);
            return cli != null ? Ok(cli) : NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Cliente cli)
        {
            await _service.CrearAsync(cli);
            return Ok("Cliente creado exitosamente");
        }

        [HttpPut]
        public async Task<IActionResult> Update([FromBody] Cliente cli)
        {
            await _service.ActualizarAsync(cli);
            return Ok("Cliente actualizado");
        }

        [HttpDelete("{cedula}")]
        public async Task<IActionResult> Delete(string cedula)
        {
            await _service.EliminarAsync(cedula);
            return Ok("Cliente eliminado");
        }
    }
}
